package org.loader.shoplib;

import org.loader.annotation.Component;

@Component("shop")
public class Shop {
}

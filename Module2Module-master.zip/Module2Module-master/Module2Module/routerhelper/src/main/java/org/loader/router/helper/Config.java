package org.loader.router.helper;

public class Config {

    public static final String PACKAGE_NAME = "org.loader.router";
    public static final String FILE_PREFIX = "Router_";
    public static final String ROUTER_MANAGER = "RouterManager";
    public static final String ROUTER_MANAGER_METHOD = "setup";
}

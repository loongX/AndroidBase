package org.loader.bbslib;

import org.loader.annotation.Component;

@Component("bbs")
public class BBS {
}
